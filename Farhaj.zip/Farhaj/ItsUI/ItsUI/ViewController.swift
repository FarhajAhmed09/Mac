//
//  ViewController.swift
//  ItsUI
//
//  Created by Farhaj Ahmed on 7/31/16.
//  Copyright © 2016 Farhaj Ahmed. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var PassTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func loginTapped(sender: AnyObject) {
        
        let userEmail = emailTextField.text
        let userPass = PassTextField.text
        
        if(userEmail!.isEmpty || (userPass?.isEmpty)!){
            displayMyAlertMessage("All fields are required")
            return
        }
        
        let userEmailStored = NSUserDefaults.standardUserDefaults().stringForKey("userEmail")
        let userPassStored = NSUserDefaults.standardUserDefaults().stringForKey("userPass")
        
        if((userEmail == userEmailStored) && (userPass == userPassStored)){
                //login successful
                NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isUserLoggedIn")
                NSUserDefaults.standardUserDefaults().synchronize()
                self.dismissViewControllerAnimated(true, completion: nil)
                
                self.performSegueWithIdentifier("loginView", sender: self)
            
        }
        else{
            let myAlert = UIAlertController(title: "Alert",message: "Username or password is incorrect", preferredStyle: UIAlertControllerStyle.Alert)
            
            let okAction = UIAlertAction(title: "Ok",style: UIAlertActionStyle.Default,handler: nil)
            
            myAlert.addAction(okAction)
            
            self.presentViewController(myAlert, animated: true, completion: nil)           }
            return
    }

    func displayMyAlertMessage(userMessage:String){
        
        let myAlert = UIAlertController(title: "Alert",message: userMessage, preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "Ok",style: UIAlertActionStyle.Default,handler: nil)
        
        myAlert.addAction(okAction)
        
        self.presentViewController(myAlert, animated: true, completion: nil)   
        
    }
    
}

