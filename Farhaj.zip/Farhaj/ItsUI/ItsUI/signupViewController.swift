//
//  signupViewController.swift
//  ItsUI
//
//  Created by Farhaj Ahmed on 7/31/16.
//  Copyright © 2016 Farhaj Ahmed. All rights reserved.
//

import Foundation
import UIKit

class signUpViewController:UIViewController{
    
    @IBOutlet weak var userNameTextField: UITextField!
    
    @IBOutlet weak var userIdTextField: UITextField!
    
    @IBOutlet weak var userEmailTextField: UITextField!
    
    @IBOutlet weak var userPassTextField: UITextField!
    
    @IBOutlet weak var userMobileTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func signUpTapped(sender: AnyObject) {
        
        let userName = userNameTextField.text
        let userId = userIdTextField.text
        let userEmail = userEmailTextField.text
        let userPass = userPassTextField.text
        let userMobile = userMobileTextField.text
        
        if(userName!.isEmpty || (userId?.isEmpty)! || (userEmail?.isEmpty)! || (userPass?.isEmpty)! || (userMobile?.isEmpty)!){
            displayMyAlertMessage("All fields are required")
            return
        }
        
        //store data
        NSUserDefaults.standardUserDefaults().setObject(userName, forKey: "userName")
        NSUserDefaults.standardUserDefaults().setObject(userId, forKey: "userId")
        NSUserDefaults.standardUserDefaults().setObject(userEmail, forKey: "userEmail")
        NSUserDefaults.standardUserDefaults().setObject(userPass, forKey: "userPass")
        NSUserDefaults.standardUserDefaults().setObject(userMobile, forKey: "userMobile")
        
        let myAlert = UIAlertController(title: "Thank You",message: "Registration successful",preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: "Ok",style: UIAlertActionStyle.Default){ action in
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        myAlert.addAction(okAction)
        self.presentViewController(myAlert, animated: true, completion: nil)
        
    }
    
    func displayMyAlertMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Alert",message: userMessage,preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "Ok",style: UIAlertActionStyle.Default,handler: nil)
        
        myAlert.addAction(okAction)
        
        self.presentViewController(myAlert, animated: true, completion: nil)
        
    }
    
}