//
//  LoggedinViewController.swift
//  ItsUI
//
//  Created by Farhaj Ahmed on 7/31/16.
//  Copyright © 2016 Farhaj Ahmed. All rights reserved..
//

import Foundation
import UIKit

class loggedInViewController:UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func logoutTapped(sender: AnyObject) {
        self.performSegueWithIdentifier("LogoutView", sender: self)
    }
    
    
}